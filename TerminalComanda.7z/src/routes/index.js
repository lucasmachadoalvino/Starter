import Home from './home'

const routes = [
  ...Home
]

export default routes