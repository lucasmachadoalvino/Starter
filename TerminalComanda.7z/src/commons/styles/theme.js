const theme = {
  color: 'red',
}
  
export default theme